#include<stdio.h>
#include<string.h>

// Task2. Build the toLower() function here.
void toLower(char a[]){
     // To be implemented by you.


}

int main(){
     char input[100];
     // Task 1. Read in user input to the char array input.


     
     // Task 3. Call the toLower function.    




     printf("%s",input);
     return 0;
}
