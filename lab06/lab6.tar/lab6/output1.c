#include <stdio.h>
int main(){
     int a = 1 , b = 2; 
     double c = -10.5;
     printf( "Input %d %d %f\n", a, b, c );
     printf( "Their sum = %f\n", a+b+c );
     return 0;
}
